package com.example.a1calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button buttonAdd, buttonSub, buttonMul, buttonDiv;
    EditText editTextN1, editTextN2;
    TextView textview;
    float num1, num2; // Change to float
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonAdd = findViewById(R.id.btn_add);
        buttonSub = findViewById(R.id.btn_sub);
        buttonMul = findViewById(R.id.btn_mul);
        buttonDiv = findViewById(R.id.btn_div);
        editTextN1 = findViewById(R.id.number1);
        editTextN2 = findViewById(R.id.number2);
        textview = findViewById(R.id.answer);

        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
    }

    public float getFloatFromEditText(EditText editText) {
        if (editText.getText().toString().equals("")) {
            Toast.makeText(this, "Enter number", Toast.LENGTH_SHORT).show();
            return 0.0f; // Return 0.0 for empty input
        } else {
            try {
                return Float.parseFloat(editText.getText().toString()); // Parse to float
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
                return 0.0f; // Return 0.0 for invalid input
            }
        }
    }

    @Override
    public void onClick(View view) {
        num1 = getFloatFromEditText(editTextN1);
        num2 = getFloatFromEditText(editTextN2);

        if (view.getId() == R.id.btn_add) {
            textview.setText("Answer = " + (num1 + num2));
        } else if (view.getId() == R.id.btn_sub) {
            textview.setText("Answer = " + (num1 - num2));
        } else if (view.getId() == R.id.btn_mul) {
            textview.setText("Answer = " + (num1 * num2));
        } else if (view.getId() == R.id.btn_div) {
            if (num2 != 0.0f) {
                textview.setText("Answer = " + (num1 / num2));
            } else {
                Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
